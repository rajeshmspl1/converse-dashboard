'use client'
import { useState, useEffect, useCallback, useRef } from 'react'
import { useStore } from '@/lib/store'
import { EXPERIENCES, INTENTS, INTENT_KEYS, MODE_LABELS, MODE_RATES, MODE_COLOR, EXP_COLOR, REVEAL_TIMINGS } from '@/lib/data'
import { formatCost, formatDuration, resolveExp } from '@/lib/utils'
import ExperienceCard from '@/components/experience/ExperienceCard'
import FocusStage from '@/components/experience/FocusStage'
import ContextBar from '@/components/cockpit/ContextBar'
import LiveCallPanel from '@/components/call/LiveCallPanel'
import { useLiveKitCall } from '@/hooks/useLiveKitCall'
import type { IntentKey } from '@/types'

interface TxLine { who: 'user' | 'ai' | 'sys'; text: string; meta?: string }

export default function Home() {
  const currency    = useStore(s => s.currency)
  const setCurrency = useStore(s => s.setCurrency)
  const baseExp     = useStore(s => s.baseExp)
  const mode        = useStore(s => s.mode)
  const setMode     = useStore(s => s.setMode)
  const callStatus  = useStore(s => s.callStatus)
  const startCall   = useStore(s => s.startCall)
  const endCall     = useStore(s => s.endCall)
  const fireIntent  = useStore(s => s.fireIntent)
  const session     = useStore(s => s.session)
  const elapsed     = useStore(s => s.elapsed)
  const liveCost    = useStore(s => s.liveCost)
  const cum         = useStore(s => s.cum)
  const tickerIdx   = useStore(s => s.tickerIdx)
  const nextTicker  = useStore(s => s.nextTicker)
  const tick        = useStore(s => s.tick)
  const reveal      = useStore(s => s.reveal)
  const revealed    = useStore(s => s.revealed)

  const [everStarted, setEverStarted]   = useState(false)
  const [transcript, setTranscript]     = useState<TxLine[]>([])
  const [toast, setToast]               = useState('')
  const [toastOn, setToastOn]           = useState(false)
  const txRef = useRef<HTMLDivElement>(null)

  // ── Real LiveKit call ──────────────────────────────────────────────────────
  const liveCall = useLiveKitCall()
  const SERVICE_B_URL = 'http://127.0.0.1:9000'

  // Timer
  useEffect(() => {
    if (callStatus !== 'active') return
    const iv = setInterval(tick, 1000)
    return () => clearInterval(iv)
  }, [callStatus, tick])

  // Ticker
  useEffect(() => {
    if (callStatus === 'active') return
    const iv = setInterval(nextTicker, 2800)
    return () => clearInterval(iv)
  }, [callStatus, nextTicker])

  // Auto scroll transcript
  useEffect(() => {
    if (txRef.current) txRef.current.scrollTop = txRef.current.scrollHeight
  }, [transcript])

  const showToast = useCallback((msg: string, dur = 4500) => {
    setToast(msg); setToastOn(true)
    setTimeout(() => setToastOn(false), dur)
  }, [])

  const addTx = useCallback((line: TxLine) => setTranscript(t => [...t, line]), [])

  // ── Big Start ──────────────────────────────────────────────────────────────
  const handleStart = useCallback(() => {
    setEverStarted(true)
    startCall()
    addTx({ who: 'ai', text: 'Welcome to HDFC Bank. How may I help you today?' })

    // ── Connect real LiveKit room ──────────────────────────────────────────
    const roomName = `hdfc__retail__${Date.now()}`
    liveCall.connect(roomName, SERVICE_B_URL)

    setTimeout(() => { reveal('cards');    showToast('👆 Experience levels — Exp 6 (lean) to Exp 2 (premium AI). Click any to switch.', 5000) }, REVEAL_TIMINGS.cards)
    setTimeout(() => { reveal('industry'); showToast('🏦 Banking & Financial Services — AI replaces your IVR, intent by intent.', 4000) }, REVEAL_TIMINGS.industry)
    setTimeout(() => { reveal('journey');  showToast('📍 You are here: Demo — Pre-UAT is your next free upgrade →', 4500) }, REVEAL_TIMINGS.journey)
    setTimeout(() => { reveal('security'); showToast('🔒 Data Security: Shared now. Secure tier (Dedicated DB) is a free upgrade.', 4500) }, REVEAL_TIMINGS.security)
    setTimeout(() => { reveal('deployment'); showToast('☁ Deployment: Cloud hosted by Converse. Hybrid & On-Prem upgrades available.', 4000) }, REVEAL_TIMINGS.deployment)
  }, [startCall, addTx, reveal, showToast, liveCall])

  // ── Toggle call ────────────────────────────────────────────────────────────
  const handleToggle = useCallback(() => {
    if (callStatus === 'active') {
      endCall()
      liveCall.disconnect()
      addTx({ who: 'ai', text: 'Thank you for calling HDFC Bank. Have a great day!' })
      addTx({ who: 'sys', text: `Call ended · ${formatDuration(elapsed)} · ${session?.events.length ?? 0} intents` })
    } else {
      startCall()
      const roomName = `hdfc__retail__${Date.now()}`
      liveCall.connect(roomName, SERVICE_B_URL)
      addTx({ who: 'ai', text: 'Welcome back to HDFC Bank. How may I assist you?' })
    }
  }, [callStatus, endCall, startCall, addTx, elapsed, session, liveCall])

  // ── Fire intent ────────────────────────────────────────────────────────────
  const handleIntent = useCallback((key: IntentKey) => {
    if (!everStarted) { handleStart(); setTimeout(() => handleIntent(key), 2000); return }
    if (callStatus !== 'active') { startCall(); setTimeout(() => handleIntent(key), 500); return }

    addTx({ who: 'user', text: INTENTS[key].text })
    const promoted = resolveExp(key, baseExp, mode) < baseExp
    setTimeout(() => {
      const ev = fireIntent(key)
      addTx({ who: 'ai', text: INTENTS[key].response, meta: `${formatCost(ev.cost, currency)} · ${(ev.latencyMs / 1000).toFixed(1)}s · Exp ${ev.resolvedExp}${ev.wasPromoted ? ' ↑ promoted' : ''}` })
    }, promoted ? 1750 : 1050)
  }, [everStarted, callStatus, baseExp, mode, currency, handleStart, startCall, addTx, fireIntent])

  const mc = MODE_COLOR[mode]
  const cardsVis   = revealed.has('cards')
  const industryVis = revealed.has('industry')
  const journeyVis  = revealed.has('journey')
  const securityVis = revealed.has('security')
  const deployVis   = revealed.has('deployment')

  return (
    <div className="flex flex-col h-screen overflow-hidden">

      {/* NAV */}
      <nav className="flex items-center justify-between px-5 h-11 border-b flex-shrink-0 sticky top-0 z-50"
        style={{ borderColor: 'var(--b1)', background: 'rgba(7,13,26,.96)' }}>
        <div className="flex items-center gap-1.5 font-extrabold text-[14px] tracking-tight" style={{ color: 'var(--bright)' }}>
          <div className="w-[26px] h-[26px] rounded-[7px] flex items-center justify-center text-[13px]"
            style={{ background: 'linear-gradient(135deg,#3370e8,#0ea8b8)' }}>🎙</div>
          Converse AI
        </div>
        <div className="hidden md:flex gap-5">
          {['Home','Demo','Pricing','Contact'].map(l => (
            <a key={l} href="#" className="text-[11px] font-medium transition-colors"
              style={{ color: 'var(--dim)' }} onMouseEnter={e => (e.target as HTMLElement).style.color = 'var(--bright)'}
              onMouseLeave={e => (e.target as HTMLElement).style.color = 'var(--dim)'}>{l}</a>
          ))}
        </div>
        <div className="flex items-center gap-1.5">
          <div className="flex rounded overflow-hidden border" style={{ background: 'var(--card)', borderColor: 'var(--b1)' }}>
            {(['inr','usd'] as const).map(c => (
              <button key={c} onClick={() => setCurrency(c)}
                className="px-2.5 py-[3px] text-[10px] font-bold font-mono transition-all"
                style={{ background: currency === c ? 'var(--blue)' : 'transparent', color: currency === c ? '#fff' : 'var(--dim)' }}>
                {c === 'inr' ? '₹ INR' : '$ USD'}
              </button>
            ))}
          </div>
          <button className="px-3 py-1 text-[11px] font-semibold rounded border transition-colors"
            style={{ borderColor: 'var(--b2)', color: 'var(--text)', background: 'transparent' }}>Sign In</button>
          <button className="px-3 py-1 text-[11px] font-semibold rounded"
            style={{ background: 'var(--blue)', color: '#fff' }}>Get Started</button>
        </div>
      </nav>

      {/* INDUSTRY BAR */}
      <div className="flex items-center justify-between px-5 border-b flex-shrink-0 overflow-hidden transition-all duration-500"
        style={{
          borderColor: 'var(--b1)', background: 'var(--surf)',
          maxHeight: industryVis ? '34px' : '0', opacity: industryVis ? 1 : 0, padding: industryVis ? '0 20px' : '0 20px',
          height: industryVis ? '34px' : '0',
        }}>
        <div className="font-bold text-[12px] flex items-center gap-2" style={{ color: 'var(--bright)' }}>
          🏦 Banking &amp; Financial Services
          <span className="text-[10px] font-normal" style={{ color: 'var(--dim)' }}>— AI replaces your IVR</span>
        </div>
        <div className="text-[10px]" style={{ color: 'var(--dim)' }}>Demo · <span style={{ color: 'var(--bright)' }}>Per-intent routing</span></div>
      </div>

      {/* CONTEXT BAR */}
      <ContextBar journeyVisible={journeyVis} securityVisible={securityVis} deployVisible={deployVis} />

      {/* MAIN */}
      <div className="flex gap-3 px-5 py-3 flex-1 overflow-hidden min-h-0">

        {/* EXP CARDS */}
        <div className="flex flex-col gap-1 w-[228px] flex-shrink-0 overflow-y-auto transition-opacity duration-300"
          style={{ opacity: cardsVis ? 1 : 0, pointerEvents: cardsVis ? 'auto' : 'none' }}>
          <div className="text-[8px] font-bold tracking-widest uppercase px-0.5 pb-1 flex-shrink-0"
            style={{ color: 'var(--dim)' }}>Experience Level</div>
          {EXPERIENCES.map((exp, i) => (
            <ExperienceCard key={exp.level} exp={exp} visible={cardsVis} delay={60 + i * 80} />
          ))}
        </div>

        {/* CALL AREA */}
        <div className="flex-1 rounded-xl border flex flex-col overflow-hidden min-h-0 relative"
          style={{ borderColor: 'var(--b1)', background: 'var(--card)' }}>

          {/* call header */}
          <div className="flex items-center justify-between px-3.5 py-2 border-b flex-shrink-0"
            style={{ borderColor: 'var(--b1)', background: 'rgba(255,255,255,.02)' }}>
            <div className="flex items-center gap-1.5 font-bold text-[11px]">
              <div className="w-[7px] h-[7px] rounded-full" style={{ background: EXP_COLOR[baseExp] }} />
              <span style={{ color: EXP_COLOR[baseExp] }}>
                Exp {baseExp}: {EXPERIENCES.find(e => e.level === baseExp)?.name}
              </span>
              <span className="font-normal text-[9px]" style={{ color: 'var(--dim)' }}>· {MODE_LABELS[mode].label} Mode</span>
            </div>
            <div className="flex gap-4 items-center">
              <div className="text-right">
                <div className="text-[8px] uppercase tracking-wide" style={{ color: 'var(--dim)' }}>Rate</div>
                <div className="font-mono text-[12px] font-semibold" style={{ color: 'var(--bright)' }}>
                  {formatCost(MODE_RATES[mode][baseExp], currency)}/intent
                </div>
              </div>
              <div className="text-right">
                <div className="text-[8px] uppercase tracking-wide" style={{ color: 'var(--dim)' }}>Session</div>
                <div className="font-mono text-[12px] font-semibold" style={{ color: 'var(--bright)' }}>
                  {formatCost(session?.totalCost ?? 0, currency)}
                </div>
              </div>
            </div>
          </div>

          {/* body */}
          {!everStarted ? (
            <FocusStage onStart={handleStart} />
          ) : (
            <div className="flex flex-1 overflow-hidden min-h-0">

              {/* LEFT */}
              <div className="w-1/2 flex flex-col border-r overflow-hidden" style={{ borderColor: 'var(--b1)' }}>

                {/* mic */}
                <div className="flex-1 flex flex-col items-center justify-center gap-2 p-3">
                  <div onClick={handleToggle}
                    className="w-14 h-14 rounded-full border-2 flex items-center justify-center cursor-pointer relative transition-all"
                    style={{
                      background: callStatus === 'active' ? 'rgba(24,196,138,.2)' : 'rgba(24,196,138,.1)',
                      borderColor: 'rgba(24,196,138,.25)',
                      animation: callStatus === 'active' ? 'micPulse 2s infinite' : 'none',
                    }}>
                    {callStatus === 'active' && <>
                      <div className="absolute rounded-full border w-[74px] h-[74px]"
                        style={{ borderColor: 'rgba(24,196,138,.15)', animation: 'wave 1.6s infinite' }} />
                      <div className="absolute rounded-full border w-[92px] h-[92px]"
                        style={{ borderColor: 'rgba(24,196,138,.15)', animation: 'wave 1.6s infinite 350ms' }} />
                    </>}
                    <span className="text-[20px]">🎙</span>
                  </div>
                  <div className="font-semibold text-[13px]" style={{ color: 'var(--bright)' }}>
                    {callStatus === 'active' ? 'Listening…' : 'Start a call'}
                  </div>
                  <button onClick={handleToggle}
                    className="flex items-center gap-1.5 px-5 py-2 rounded-lg font-extrabold text-[12px] tracking-tight transition-all hover:opacity-85 hover:scale-[1.02]"
                    style={callStatus === 'active'
                      ? { background: '#d44444', color: '#fff' }
                      : { background: mc.start, color: mc.startText }
                    }>
                    {callStatus === 'active' ? '📵 End Call' : '📞 Start Call'}
                  </button>
                </div>

                {/* mode panel */}
                <div className="px-3 py-2.5 border-t flex-shrink-0" style={{ borderColor: 'var(--b1)', background: 'rgba(0,0,0,.1)' }}>
                  <div className="text-[8.5px] font-bold tracking-wide uppercase mb-2 flex items-center gap-1.5" style={{ color: 'var(--bright)' }}>
                    <div className="w-[3px] h-[11px] rounded-sm" style={{ background: 'var(--blue)' }} />
                    Routing Mode
                  </div>
                  <div className="flex gap-1.5 mb-1.5">
                    {(['premium','complexity','sales','hybrid'] as const).map(m => {
                      const c = MODE_COLOR[m]; const active = mode === m
                      return (
                        <button key={m} onClick={() => setMode(m)}
                          className="flex-1 py-1.5 rounded-md border-[1.5px] text-[10px] font-bold flex flex-col items-center gap-0.5 transition-all"
                          style={active
                            ? { background: c.bg, borderColor: c.border, color: c.text, boxShadow: `0 0 10px ${c.bg}` }
                            : { background: 'transparent', borderColor: 'var(--b2)', color: 'var(--dim)' }
                          }>
                          {m.charAt(0).toUpperCase() + m.slice(1)}
                          <span className="font-mono text-[8px]">{formatCost(MODE_RATES[m][baseExp], currency)}</span>
                        </button>
                      )
                    })}
                  </div>
                  <div className="text-[8.5px] leading-relaxed px-2 py-1 rounded border-l-2"
                    style={{ background: 'rgba(255,255,255,.02)', borderColor: 'var(--b2)', color: 'var(--dim)' }}>
                    {MODE_LABELS[mode].desc}
                  </div>
                </div>

                {/* ticker */}
                <div className="px-3 py-1.5 border-t flex-shrink-0" style={{ borderColor: 'var(--b1)' }}>
                  <div className="text-[7.5px] font-bold tracking-wide uppercase mb-1.5" style={{ color: 'var(--dim)' }}>
                    Click to simulate intent
                  </div>
                  <div className="overflow-hidden rounded-md border cursor-pointer transition-colors h-7"
                    style={{ background: 'rgba(255,255,255,.03)', borderColor: 'var(--b1)' }}
                    onClick={() => { handleIntent(INTENT_KEYS[tickerIdx]); nextTicker() }}>
                    <div className="flex flex-col transition-transform duration-[450ms]"
                      style={{ transform: `translateY(-${tickerIdx * 28}px)` }}>
                      {[...INTENT_KEYS, ...INTENT_KEYS].map((k, i) => {
                        const rExp = resolveExp(k, baseExp, mode)
                        return (
                          <div key={i} className="h-7 flex items-center px-2.5 gap-2 flex-shrink-0">
                            <span className="italic text-[10px] flex-1 overflow-hidden text-ellipsis whitespace-nowrap"
                              style={{ color: 'var(--bright)' }}>"{INTENTS[k].text}"</span>
                            <span className="text-[7px] font-bold font-mono px-1 py-px rounded flex-shrink-0"
                              style={{ background: `${EXP_COLOR[rExp]}22`, color: EXP_COLOR[rExp] }}>E{rExp}</span>
                            <span className="text-[8px] flex-shrink-0" style={{ color: 'var(--dim)' }}>↵</span>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                </div>
              </div>

              {/* RIGHT: transcript + meters */}
              <div className="flex-1 flex flex-col overflow-hidden">

                {/* transcript */}
                <div ref={txRef} className="flex-1 overflow-y-auto p-2.5 flex flex-col gap-1.5">
                  {transcript.length === 0 && (
                    <div className="flex flex-col items-center justify-center h-full gap-1.5" style={{ color: 'var(--dim)' }}>
                      <div className="text-[22px] opacity-25">💬</div>
                      <div className="text-[10px]">Transcript will appear here</div>
                    </div>
                  )}
                  {transcript.map((tx, i) => (
                    <div key={i} className="flex gap-1.5 items-start">
                      <div className={`text-[7.5px] font-bold w-7 flex-shrink-0 mt-0.5 px-1 py-px rounded text-center`}
                        style={{
                          background: tx.who === 'user' ? 'rgba(51,112,232,.15)' : tx.who === 'ai' ? 'rgba(24,196,138,.12)' : 'rgba(255,255,255,.05)',
                          color: tx.who === 'user' ? '#80aaf4' : tx.who === 'ai' ? 'var(--green)' : 'var(--dim)',
                        }}>
                        {tx.who === 'user' ? 'YOU' : tx.who === 'ai' ? 'AI' : '···'}
                      </div>
                      <div className="flex-1 rounded-md border p-1.5"
                        style={{
                          background: tx.who === 'user' ? 'rgba(51,112,232,.07)' : 'var(--card2)',
                          borderColor: tx.who === 'user' ? 'rgba(51,112,232,.15)' : 'var(--b1)',
                        }}>
                        <div className="text-[10px] leading-snug" style={{ color: 'var(--text)' }}>{tx.text}</div>
                        {tx.meta && <div className="font-mono text-[8px] mt-0.5" style={{ color: 'var(--amber)' }}>{tx.meta}</div>}
                      </div>
                    </div>
                  ))}
                </div>

                {/* meters */}
                <div className="border-t flex-shrink-0" style={{ borderColor: 'var(--b1)' }}>
                  <div className="flex">
                    {[
                      { label: '⏱ Duration', val: formatDuration(elapsed), sub: callStatus === 'active' ? 'Running…' : 'Idle', color: 'var(--bright)' },
                      { label: '💰 Cost',     val: formatCost(liveCost, currency), sub: 'This call', color: 'var(--green)' },
                      { label: '🎯 Intents',  val: String(session?.events.length ?? 0), sub: 'Handled', color: '#8a4ee8' },
                    ].map((m, i) => (
                      <div key={i} className="flex-1 p-2 border-r last:border-r-0" style={{ borderColor: 'var(--b1)' }}>
                        <div className="text-[7.5px] font-bold tracking-wide uppercase mb-0.5" style={{ color: 'var(--dim)' }}>{m.label}</div>
                        <div className="font-mono text-[18px] font-semibold leading-none" style={{ color: m.color }}>{m.val}</div>
                        <div className="text-[7.5px] mt-0.5" style={{ color: 'var(--dim)' }}>{m.sub}</div>
                      </div>
                    ))}
                  </div>

                  {/* cumulative */}
                  <div className="flex items-center gap-4 px-2.5 py-1.5 border-t" style={{ borderColor: 'var(--b1)', background: 'rgba(0,0,0,.15)' }}>
                    <div className="text-[7.5px] font-bold uppercase tracking-wide whitespace-nowrap" style={{ color: 'var(--dim)' }}>Totals</div>
                    {[
                      { l: 'Calls', v: String(cum.calls) },
                      { l: 'Intents', v: String(cum.intents) },
                      { l: 'Cost', v: formatCost(cum.totalCost, currency) },
                      { l: 'Avg/Intent', v: cum.avgCostPerIntent > 0 ? formatCost(cum.avgCostPerIntent, currency) : '—' },
                    ].map(c => (
                      <div key={c.l} className="flex flex-col gap-px">
                        <div className="text-[7px] uppercase tracking-wide" style={{ color: 'var(--dim)' }}>{c.l}</div>
                        <div className="font-mono text-[11px] font-semibold" style={{ color: 'var(--bright)' }}>{c.v}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* promo strip */}
          <div className="flex items-center gap-1.5 px-3.5 py-1 border-t flex-shrink-0"
            style={{ borderColor: 'rgba(51,112,232,.18)', background: 'linear-gradient(90deg,#0f2050,#0c3040)' }}>
            <span className="text-[8px] font-extrabold px-1 py-px rounded"
              style={{ background: 'var(--amber)', color: '#080d18' }}>FREE</span>
            <span className="text-[9px]" style={{ color: '#6090b0' }}>
              Test with real AI · No credit card needed · Sign up to connect your SIP trunk
            </span>
          </div>
        </div>

        {/* LIVE CALL PANEL — real LiveKit connection + IVR dialpad */}
        <div className="w-[280px] flex-shrink-0 overflow-y-auto">
          <LiveCallPanel state={liveCall.state} onDTMF={liveCall.pressDTMF} />
        </div>

      </div>

      {/* TOAST */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 rounded-lg px-4 py-2.5 z-50 max-w-md text-center text-[11px] leading-relaxed shadow-2xl pointer-events-none transition-all duration-300"
        style={{
          background: 'rgba(11,19,32,.97)', border: '1px solid var(--b2)',
          opacity: toastOn ? 1 : 0, transform: `translateX(-50%) translateY(${toastOn ? 0 : 8}px)`,
        }}
        dangerouslySetInnerHTML={{ __html: toast }} />
    </div>
  )
}
