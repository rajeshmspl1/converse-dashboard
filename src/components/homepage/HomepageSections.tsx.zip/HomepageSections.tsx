'use client'

interface Props {
  onStartCall: () => void
  onToggleIVRBar: () => void
  onSignUp?: () => void
}

export default function HomepageSections({ onStartCall, onToggleIVRBar, onSignUp }: Props) {

  return (
    <div className="overflow-y-auto flex-1" style={{ background: 'var(--bg)' }}>
      <style>{`
        @keyframes heroGlow { 0%,100% { box-shadow: 0 0 4px #22c55e; } 50% { box-shadow: 0 0 14px #22c55e; } }
        @keyframes fadeInUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>

      {/* ═══ HERO ═══ */}
      <section className="text-center px-6 pt-16 pb-12 relative overflow-hidden">
        {/* Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border mb-7 text-[12px]"
          style={{ borderColor: 'rgba(255,255,255,.1)', background: 'rgba(255,255,255,.04)', color: 'rgba(255,255,255,.65)' }}>
          <span className="w-[7px] h-[7px] rounded-full" style={{ background: '#22c55e', animation: 'heroGlow 2s infinite' }} />
          Live AI · No pre-recorded responses · Zero integration
        </div>

        {/* Headline */}
        <h1 className="font-black leading-[1.08] mb-3.5 tracking-tight" style={{ fontSize: 'clamp(32px, 5vw, 56px)', letterSpacing: '-1.5px' }}>
          Migrate your IVR to AI.<br />
          <span style={{ background: 'linear-gradient(90deg, #60a5fa, #34d399, #a78bfa)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>
            17 minutes flat.
          </span>
        </h1>

        <p className="text-[17px] mb-2 mx-auto leading-relaxed" style={{ color: 'rgba(255,255,255,.45)', maxWidth: 540 }}>
          Zero cost. Zero integration. No IT.
        </p>
        {/* CTA Row */}
        <div className="flex gap-5 justify-center mb-3 flex-wrap">
          <button onClick={onStartCall}
            className="px-10 py-3.5 rounded-[10px] text-[16px] font-bold border-none cursor-pointer transition-all hover:-translate-y-0.5"
            style={{ background: '#3b82f6', color: '#fff', boxShadow: '0 4px 20px rgba(59,130,246,.3)' }}>
            ▶ Try Live Demo
          </button>
          <button onClick={() => onSignUp?.()}
            className="px-7 py-3.5 rounded-[10px] text-[14px] font-semibold border cursor-pointer transition-all hover:border-white/30 hover:text-white"
            style={{ background: 'transparent', color: 'rgba(255,255,255,.6)', borderColor: 'rgba(255,255,255,.12)' }}>
            See How Migration Works →
          </button>
        </div>

        {/* Trust line */}
        <p className="text-[13px] mb-4" style={{ color: 'rgba(255,255,255,.5)' }}>
          Experience the AI live. Zero integration. Zero upfront cost. No IT ticket.
        </p>

        {/* Badge row */}
        <div className="flex gap-2 justify-center flex-wrap mb-2">
          {['Live in 17 min', 'No stack change', 'No IT dependency'].map((b, i) => (
            <span key={i} className="px-3 py-1 rounded-full text-[11px] font-medium"
              style={{ border: '1px solid rgba(0,201,177,.25)', color: '#00c9b1', background: 'rgba(0,201,177,.06)' }}>
              {b}
            </span>
          ))}
        </div>
      </section>

      {/* ═══ STAT CARDS ═══ */}
      <div className="mx-auto -mt-7 relative z-[2]" style={{ maxWidth: 800 }}>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-px rounded-[14px] overflow-hidden" style={{ background: 'var(--b1)' }}>
          {[
            { icon: '⚡', val: '17 min', label: 'IVR → AI', sub: 'No IT ticket. No integration.' },
            { icon: '🔌', val: 'Zero', label: 'Integration', sub: 'Your existing IVR stays live.' },
            { icon: '₹', val: 'Per intent', label: 'Pricing', sub: 'Pay only when it resolves.' },
            { icon: '🛡️', val: 'Your data', label: 'Stays yours', sub: 'Shared, dedicated, or on-prem.' },
          ].map((s, i) => (
            <div key={i} className="p-6 text-center" style={{ background: 'var(--s1, #0d1526)' }}>
              <div className="text-[22px] mb-2">{s.icon}</div>
              <div className="text-[18px] font-bold mb-0.5">{s.val}</div>
              <div className="text-[11px] leading-tight" style={{ color: 'var(--tx3, #4a5f80)' }}>{s.label}<br />{s.sub}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ═══ TRUST 7 ═══ */}
      <section className="mx-auto px-6 py-10" style={{ maxWidth: 1040 }}>
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
          {[
            { emoji: '🔌', tt: 'Zero Integration', ts: 'No SIP. No API. No code.' },
            { emoji: '🆓', tt: 'Zero Cost', ts: 'Live UAT free 3 months.*' },
            { emoji: '⚡', tt: '17 Min Go-Live', ts: 'Explore to production.' },
            { emoji: '👔', tt: 'Non-Technical', ts: 'Built for CXOs.' },
            { emoji: '🧠', tt: 'Multi-Modal LLM', ts: 'Pick your AI model at will.' },
            { emoji: '🏆', tt: '4 Industry Firsts', ts: 'Intent billing · LLM swap · Sales · CRM routing' },
            { emoji: '🔧', tt: 'Bring Your Own', ts: 'Carrier · Infra · LLMs · CCaaS · Telephony' },
          ].map((t, i) => (
            <div key={i} className="px-2.5 py-4 rounded-[10px] text-center border transition-all hover:-translate-y-0.5 hover:border-[#00c9b1]"
              style={{ background: 'var(--s1, #0d1526)', borderColor: 'var(--b1, #1c2d45)' }}>
              <div className="text-[22px] mb-1.5">{t.emoji}</div>
              <div className="text-[11px] font-bold mb-1" style={{ color: '#00c9b1' }}>{t.tt}</div>
              <div className="text-[9px] leading-tight" style={{ color: 'var(--tx3, #4a5f80)' }}>{t.ts}</div>
            </div>
          ))}
        </div>
        <div className="text-right text-[8px] mt-1" style={{ color: 'var(--tx3, #4a5f80)' }}>*conditions apply</div>
      </section>

      <hr style={{ border: 'none', height: 1, background: 'var(--b1, #1c2d45)', margin: 0 }} />

      {/* ═══ 17-MINUTE TIMELINE ═══ */}
      <section className="mx-auto px-6 py-14" style={{ maxWidth: 940 }}>
        <div className="text-center mb-2 text-[11px] font-semibold uppercase tracking-widest" style={{ color: 'var(--tx3, #4a5f80)' }}>
          Fastest IVR migration in the industry
        </div>
        <h2 className="text-center text-[28px] font-bold mb-2">Live in 17 minutes.</h2>
        <p className="text-center text-[14px] mb-8 mx-auto leading-relaxed" style={{ color: 'var(--tx2, #7a90b5)', maxWidth: 560 }}>
          No IT dependency. No changes to your existing system. Explore to production in 17 minutes.
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1 relative">
          {/* Connecting line (visible on sm+) */}
          <div className="hidden sm:block absolute z-0" style={{ top: 20, left: '12%', right: '12%', height: 2, background: `linear-gradient(90deg, #00c9b1, #00c9b1 33%, var(--b1, #1c2d45) 33%)` }} />

          {[
            { icon: '🔍', time: '5 min', title: 'Explore & Try', desc: 'Start a live AI call. Hear it handle real customer intents.', active: true, done: false },
            { icon: '🚀', time: '5 min', title: 'Pilot Live', desc: 'Real calls, limited volume. Full monitoring + analytics.', active: false, done: false },
            { icon: '🔬', time: '5 min', title: 'Production Test', desc: 'Run all customer journeys. Validate every flow end-to-end.', active: false, done: false },
            { icon: '✅', time: '2 min', title: 'Production Live', desc: 'Dashboards, compliance, multilingual, agent handoff — all running.', active: false, done: true },
          ].map((step, i) => (
            <div key={i} className="text-center relative z-[1]">
              <div className="w-10 h-10 rounded-full flex items-center justify-center text-[16px] mx-auto mb-2"
                style={{
                  background: step.active ? '#00c9b1' : step.done ? '#00de7a' : 'var(--s1, #0d1526)',
                  border: (!step.active && !step.done) ? '2px solid var(--b2, #243558)' : 'none',
                }}>
                {step.icon}
              </div>
              <div className="text-[9px] font-semibold mb-0.5" style={{ color: step.active ? '#00c9b1' : step.done ? '#00de7a' : 'var(--tx3, #4a5f80)' }}>
                {step.time}
              </div>
              <div className="text-[12px] font-bold mb-1">{step.title}</div>
              <div className="text-[10px] px-1 leading-snug" style={{ color: 'var(--tx3, #4a5f80)' }}>{step.desc}</div>
            </div>
          ))}
        </div>

        <div className="text-center mt-5 mb-2">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border text-[11px] font-semibold"
            style={{ borderColor: 'rgba(0,222,122,.2)', background: 'rgba(0,222,122,.04)', color: '#00de7a' }}>
            🆓 Test free for up to 3 months — at any stage or all stages
          </div>
        </div>

        <div className="text-center mt-7">
          <button onClick={onStartCall}
            className="px-8 py-3 text-[14px] rounded-[10px] border-none font-bold cursor-pointer"
            style={{ background: '#00c9b1', color: '#000', boxShadow: '0 4px 16px rgba(0,201,177,.3)' }}>
            📞 Try Live Demo
          </button>
          <div className="text-[10px] mt-2" style={{ color: 'var(--tx3, #4a5f80)' }}>
            Zero integration · Zero cost · In 17 minutes
          </div>
        </div>
      </section>

      <hr style={{ border: 'none', height: 1, background: 'var(--b1, #1c2d45)', margin: 0 }} />

      {/* ═══ JOURNEY CARDS ═══ */}
      <section className="mx-auto px-6 py-14" style={{ maxWidth: 940 }}>
        <div className="text-center mb-2 text-[11px] font-semibold uppercase tracking-widest" style={{ color: 'var(--tx3)' }}>
          4 Industry Firsts
        </div>
        <h2 className="text-center text-[28px] font-bold mb-2">Experience each one — live.</h2>
        <p className="text-center text-[14px] mb-8 mx-auto leading-relaxed" style={{ color: 'var(--tx2)', maxWidth: 560 }}>
          Each journey demonstrates a capability no other IVR vendor offers. Try them all in under 5 minutes.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {[
            { icon: '⚡', name: 'Per-Intent Pricing', desc: 'Pay per resolved business action. Not per minute. Disconnects cost zero.', border: 'rgba(0,201,177,.2)', cta: '#00c9b1' },
            { icon: '🎯', name: 'CRM Value Routing', desc: 'Gold customers get Exp 2 (₹1.47). Bronze gets Exp 5 (₹0.47). CRM-driven.', border: 'rgba(245,166,35,.2)', cta: '#f5a623' },
            { icon: '🔥', name: 'In-Call Escalation', desc: 'AI detects frustration mid-call and instantly upgrades the agent. Hot-swap.', border: 'rgba(240,48,96,.2)', cta: '#f03060' },
            { icon: '💰', name: 'Sales Discovery', desc: 'AI analyzes CRM mid-call. Detects upsell. Creates leads. Commission per conversion.', border: 'rgba(0,222,122,.2)', cta: '#00de7a' },
          ].map((j, i) => (
            <div key={i} className="p-5 rounded-xl cursor-pointer transition-all hover:-translate-y-0.5"
              onClick={onStartCall}
              style={{ background: 'var(--s1)', border: `1px solid ${j.border}` }}>
              <div className="text-[20px] mb-1.5">{j.icon}</div>
              <div className="text-[14px] font-bold mb-1">{j.name}</div>
              <div className="text-[11px] leading-relaxed mb-2" style={{ color: 'var(--tx3)' }}>{j.desc}</div>
              <div className="text-[10px] font-semibold" style={{ color: j.cta }}>Try it →</div>
            </div>
          ))}
        </div>
      </section>

      <hr style={{ border: 'none', height: 1, background: 'var(--b1)', margin: 0 }} />

      {/* ═══ INDUSTRIES ═══ */}
      <section className="mx-auto px-6 py-14" style={{ maxWidth: 940 }}>
        <div className="text-center mb-2 text-[11px] font-semibold uppercase tracking-widest" style={{ color: 'var(--tx3)' }}>
          Choose your context
        </div>
        <h2 className="text-center text-[28px] font-bold mb-2">Hear it in your industry</h2>
        <p className="text-center text-[14px] mb-8 mx-auto leading-relaxed" style={{ color: 'var(--tx2)', maxWidth: 560 }}>
          Click an industry — get a live AI call handling your sector&apos;s real customer intents, right now.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            { emoji: '🏦', name: 'Banking & Finance', intents: 'Account balance · Card blocking · Loan EMI · Mini statement · FD rates · Cheque book' },
            { emoji: '🛡️', name: 'Insurance', intents: 'Claim status · Policy renewal · Premium payment · New policy · Agent connect' },
            { emoji: '🏥', name: 'Healthcare', intents: 'Appointments · Prescriptions · Lab results · Doctor availability · Billing' },
            { emoji: '📱', name: 'Telecom', intents: 'Plan upgrade · Data usage · SIM replacement · Bill payment · Roaming' },
            { emoji: '🛒', name: 'E-Commerce', intents: 'Order tracking · Return request · Refund status · Store locator · Delivery' },
            { emoji: '🏨', name: 'Hospitality', intents: 'Room booking · Check-in · Room service · Spa · Late checkout · Concierge' },
          ].map((ind, i) => (
            <div key={i} onClick={onStartCall}
              className="p-6 rounded-xl border text-center cursor-pointer transition-all hover:-translate-y-1 hover:border-[#00c9b1]"
              style={{ background: 'var(--s1)', borderColor: 'var(--b1)' }}>
              <div className="text-[28px] mb-2">{ind.emoji}</div>
              <h4 className="text-[14px] font-bold mb-1">{ind.name}</h4>
              <p className="text-[10px] mb-2.5 leading-relaxed" style={{ color: 'var(--tx3)' }}>{ind.intents}</p>
              <span className="px-3.5 py-1.5 rounded-md text-[10px] font-semibold transition-all"
                style={{ background: 'rgba(0,201,177,.1)', color: '#00c9b1' }}>
                Start Call →
              </span>
            </div>
          ))}
        </div>
      </section>

      <hr style={{ border: 'none', height: 1, background: 'var(--b1)', margin: 0 }} />

      {/* ═══ CX CHECKLIST ═══ */}
      <section className="mx-auto px-6 py-14" style={{ maxWidth: 940 }}>
        <div className="text-center mb-2 text-[11px] font-semibold uppercase tracking-widest" style={{ color: 'var(--tx3)' }}>
          Built for regulated industries
        </div>
        <h2 className="text-center text-[28px] font-bold mb-2">Your CX team&apos;s checklist. Answered.</h2>
        <p className="text-center text-[14px] mb-8 mx-auto leading-relaxed" style={{ color: 'var(--tx2)', maxWidth: 560 }}>
          Every question your compliance and IT team will ask — already handled.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[
            { icon: '🛡️', title: 'Data stays in your jurisdiction', desc: 'Choose shared, dedicated, or on-premise. Voice data never leaves your region.', tags: ['Shared', 'Dedicated', 'On-Prem', 'India · UAE · EU'] },
            { icon: '🎙️', title: 'Every call recorded and scored', desc: 'Full recordings, transcripts, intent success, containment rate. QA built in.', tags: ['Recordings', 'Transcripts', 'Intent analytics', 'CSAT'] },
            { icon: '🤝', title: 'Seamless agent handoff', desc: 'AI confidence drops → call transfers with full context. Zero dead air.', tags: ['Clean transfer', 'Full context', 'Configurable'] },
            { icon: '🔌', title: 'Zero integration — truly', desc: 'IVR keeps running unchanged. No API changes. No IT approval.', tags: ['No API', 'IVR untouched', 'No contracts'] },
            { icon: '📊', title: 'Per-intent pricing — industry first', desc: '₹0.47–₹3.75 per resolved intent. Disconnects cost zero.', tags: ['₹0.47 Essential', '₹3.75 Ultra'], highlight: true },
            { icon: '🌐', title: 'Multilingual — no extra setup', desc: 'Hindi, Tamil, Telugu, Kannada, Bengali, English. Auto-detected per call.', tags: ['Auto detect', '10+ Indian', 'No config'] },
            { icon: '🔧', title: 'Bring your own stack', desc: 'Your carrier, your infra, your LLMs, your CCaaS, your telephony. Plug and play.', tags: ['BYO Carrier', 'BYO Infra', 'BYO LLM', 'BYO CCaaS', 'BYO Telephony'] },
          ].map((cx, i) => (
            <div key={i} className="p-5 rounded-xl border transition-all hover:border-white/10"
              style={{ background: 'var(--s1)', borderColor: 'var(--b1)' }}>
              <div className="text-[20px] mb-2.5">{cx.icon}</div>
              <h4 className="text-[13px] font-bold mb-1.5">{cx.title}</h4>
              <p className="text-[11px] leading-relaxed mb-2" style={{ color: 'var(--tx3)' }}>{cx.desc}</p>
              <div className="flex gap-1 flex-wrap">
                {cx.tags.map((tag, ti) => (
                  <span key={ti} className="px-2 py-0.5 rounded text-[8px]"
                    style={{
                      background: cx.highlight ? 'rgba(0,201,177,.1)' : 'var(--s2, #111d30)',
                      color: cx.highlight ? '#00c9b1' : 'var(--tx3)',
                    }}>{tag}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <hr style={{ border: 'none', height: 1, background: 'var(--b1)', margin: 0 }} />

      {/* ═══ PRICING TABLE ═══ */}
      <section className="mx-auto px-6 py-14" style={{ maxWidth: 940 }}>
        <div className="text-center mb-2 text-[11px] font-semibold uppercase tracking-widest" style={{ color: 'var(--tx3)' }}>
          Transparent · No surprises
        </div>
        <h2 className="text-center text-[28px] font-bold mb-2">Pay per intent resolved. Not per minute.</h2>
        <p className="text-center text-[14px] mb-8 mx-auto leading-relaxed" style={{ color: 'var(--tx2)', maxWidth: 560 }}>
          Traditional IVR ports bill ₹6–8/min regardless. With Converse, idle calls cost zero.
        </p>

        <div className="rounded-xl border overflow-hidden" style={{ borderColor: 'var(--b1)' }}>
          <table className="w-full" style={{ borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--s1)' }}>
                {['#', 'Experience', 'AI Stack', 'Price/intent', 'Latency'].map((h, i) => (
                  <th key={i} className={`px-4 py-3 text-[10px] font-semibold uppercase tracking-wide ${i >= 3 ? 'text-right' : 'text-left'}`}
                    style={{ color: 'var(--tx3)', borderBottom: '1px solid var(--b1)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                { n: 1, name: 'Ultra', sub: 'Premium', stack: 'ElevenLabs · GPT-4o-mini · Azure STT', price: '₹3.75', latency: '~700ms', color: '#f03060' },
                { n: 2, name: 'Conversational', sub: 'NRI', stack: 'GPT-4o Realtime (end-to-end)', price: '₹1.47', latency: '~300ms', color: '#f5a623' },
                { n: 3, name: 'Gemini', sub: 'Popular', stack: 'Gemini 2.5 Flash (end-to-end)', price: '₹1.05', latency: '~300ms', color: '#00de7a', popular: true },
                { n: 4, name: 'Sarvam', sub: 'Indic', stack: 'Sarvam · GPT-4o-mini · Sarvam', price: '₹0.50', latency: '~800ms', color: '#3d85e0' },
                { n: 5, name: 'Essential', sub: 'Functional', stack: 'Azure STT · GPT-4o-mini · Azure TTS', price: '₹0.47', latency: '~900ms', color: '#8b5cf6' },
              ].map((row) => (
                <tr key={row.n} style={{ background: row.popular ? 'rgba(0,201,177,.03)' : 'transparent' }}>
                  <td className="px-4 py-3.5 text-[12px]" style={{ borderBottom: '1px solid rgba(28,45,69,.4)', color: 'var(--tx2)' }}>{row.n}</td>
                  <td className="px-4 py-3.5 text-[13px] font-bold" style={{ borderBottom: '1px solid rgba(28,45,69,.4)', color: row.color }}>
                    {row.name} <span className="text-[9px] font-normal" style={{ color: row.popular ? '#00c9b1' : 'var(--tx3)' }}>{row.sub}</span>
                  </td>
                  <td className="px-4 py-3.5 text-[12px]" style={{ borderBottom: '1px solid rgba(28,45,69,.4)', color: 'var(--tx2)' }}>{row.stack}</td>
                  <td className="px-4 py-3.5 text-right text-[12px] font-bold" style={{ borderBottom: '1px solid rgba(28,45,69,.4)', color: row.popular ? '#00c9b1' : 'var(--tx2)' }}>{row.price}</td>
                  <td className="px-4 py-3.5 text-right text-[12px]" style={{ borderBottom: '1px solid rgba(28,45,69,.4)', color: 'var(--tx2)' }}>{row.latency}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="px-4 py-2.5 text-[9px]" style={{ background: 'var(--s2, #111d30)', color: 'var(--tx3)', borderTop: '1px solid var(--b1)' }}>
            All prices include STT + LLM + TTS + infrastructure. 35s/intent. 2.5× margin. ₹84 = $1.
          </div>
        </div>
      </section>

      {/* ═══ FINAL CTA ═══ */}
      <section className="mx-auto px-6 pb-16" style={{ maxWidth: 940 }}>
        <div className="text-center p-12 rounded-2xl border"
          style={{ background: 'linear-gradient(135deg, rgba(59,130,246,.06), rgba(6,182,212,.04))', borderColor: 'rgba(59,130,246,.1)' }}>
          <h2 className="text-[24px] font-bold mb-2">Ready to migrate your IVR? 17 minutes from now.</h2>
          <p className="text-[13px] mb-5" style={{ color: 'var(--tx3)' }}>Lower cost to serve, improve CSAT, and resolve customer intents faster.</p>
          <div className="flex gap-2.5 justify-center flex-wrap">
            <button onClick={onStartCall}
              className="px-8 py-3.5 rounded-[10px] text-[15px] font-bold border-none cursor-pointer"
              style={{ background: '#00c9b1', color: '#000', boxShadow: '0 4px 16px rgba(0,201,177,.3)' }}>
              ▶ Try Live Demo
            </button>
            <button onClick={() => onSignUp?.()}
              className="px-7 py-3.5 rounded-[10px] text-[14px] font-semibold border cursor-pointer"
              style={{ background: 'transparent', color: 'var(--tx2)', borderColor: 'var(--b1)' }}>
              See How Migration Works →
            </button>
          </div>
          <div className="text-[10px] mt-2 mb-2" style={{ color: 'var(--tx3)' }}>
            Zero integration · Zero cost · In 17 minutes
          </div>
          <div className="flex gap-4 justify-center mt-3.5 flex-wrap text-[11px]" style={{ color: 'var(--tx3)' }}>
            <span>✓ No credit card</span><span>✓ Free UAT 3 months</span><span>✓ Your IVR stays live</span><span>✓ Cancel anytime</span>
          </div>
        </div>
      </section>

      {/* bottom spacer for floating IVR bar */}
      <div className="h-16" />
    </div>
  )
}
