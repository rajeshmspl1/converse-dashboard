'use client'
import Link from 'next/link'
import PageShell from '@/components/PageShell'

const INDUSTRIES = [
  {
    icon: '🏦', name: 'Banking & Finance',
    desc: 'Account queries, card management, loan information, fixed deposits, cheque books — all handled conversationally with SEBI/RBI compliance.',
    intents: ['Account Balance', 'Mini Statement', 'Card Block', 'Loan EMI', 'FD Rates', 'Cheque Book'],
    compliance: '🔒 SEBI/RBI compliant · Data stays in India · Full audit trail',
    color: '#3370e8',
  },
  {
    icon: '🛡️', name: 'Insurance',
    desc: 'Claim status, policy renewals, premium payments, new policy queries, agent connect — all with IRDAI compliance.',
    intents: ['Claim Status', 'Policy Renewal', 'Premium Payment', 'New Policy', 'Agent Connect'],
    compliance: '🔒 IRDAI compliant · Policyholder data protected',
    color: '#e09820',
  },
  {
    icon: '🏥', name: 'Healthcare',
    desc: 'Appointment scheduling, prescription refills, lab results, doctor availability, billing — HIPAA-ready architecture.',
    intents: ['Appointments', 'Prescriptions', 'Lab Results', 'Doctor Availability', 'Billing'],
    compliance: '🔒 HIPAA-ready · Patient data encrypted',
    color: '#ef4444',
  },
  {
    icon: '📱', name: 'Telecom',
    desc: 'Plan upgrades, data usage, SIM replacement, bill payments, roaming activation — highest call volume industry, biggest ROI.',
    intents: ['Plan Upgrade', 'Data Usage', 'SIM Replace', 'Bill Payment', 'Roaming', 'Number Port'],
    compliance: '🔒 TRAI compliant · CDR data protected',
    color: '#8a4ee8',
  },
  {
    icon: '🛒', name: 'E-Commerce',
    desc: 'Order tracking, returns, refund status, delivery changes, store locator — reduce support tickets by 80%.',
    intents: ['Order Tracking', 'Returns', 'Refund Status', 'Delivery Change', 'Store Locator'],
    compliance: '🔒 PCI compliant · Payment data secured',
    color: '#18c48a',
  },
  {
    icon: '🏨', name: 'Hospitality',
    desc: 'Room bookings, check-in, room service, spa, late checkout, concierge — 24/7 voice AI that never sleeps.',
    intents: ['Room Booking', 'Check-in', 'Room Service', 'Late Checkout', 'Concierge', 'Spa'],
    compliance: '🔒 Guest data protected · PCI compliant',
    color: '#06b6d4',
  },
]

export default function IndustriesPage() {
  return (
    <PageShell>
      {/* Hero */}
      <div className="max-w-[940px] mx-auto px-6 pt-12 pb-8 text-center">
        <div className="text-[11px] font-semibold uppercase tracking-[2px] mb-2" style={{ color: 'var(--dim)' }}>
          One platform · Every industry
        </div>
        <h1 className="text-[32px] font-bold mb-3" style={{ color: 'var(--bright)' }}>Built for your industry</h1>
        <p className="text-[14px] max-w-[560px] mx-auto leading-relaxed" style={{ color: 'var(--text)' }}>
          Converse AI handles real customer intents across 6+ industries. Click any industry to try it live.
        </p>
      </div>

      {/* Industry cards */}
      <div className="max-w-[940px] mx-auto px-6 pb-14">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {INDUSTRIES.map(ind => (
            <div key={ind.name} className="rounded-2xl p-6 border transition-all hover:translate-y-[-2px]"
              style={{ background: 'var(--card)', borderColor: 'var(--b1)' }}>
              <div className="text-[32px] mb-3">{ind.icon}</div>
              <h3 className="text-[18px] font-bold mb-2" style={{ color: 'var(--bright)' }}>{ind.name}</h3>
              <p className="text-[12px] leading-relaxed mb-4" style={{ color: 'var(--dim)' }}>{ind.desc}</p>

              <div className="text-[9px] font-semibold uppercase tracking-[1px] mb-2" style={{ color: 'var(--dim)' }}>
                Mapped Intents
              </div>
              <div className="flex flex-wrap gap-1.5 mb-4">
                {ind.intents.map(intent => (
                  <span key={intent} className="px-2.5 py-1 rounded-md text-[9px]"
                    style={{ background: 'var(--card2)', color: 'var(--text)' }}>
                    {intent}
                  </span>
                ))}
              </div>

              <div className="text-[9px] mb-4" style={{ color: 'var(--dim)' }}>{ind.compliance}</div>

              <Link href="/"
                className="inline-flex items-center gap-1.5 px-5 py-2 rounded-lg text-[11px] font-bold no-underline transition-opacity hover:opacity-85"
                style={{ background: 'var(--green)', color: '#050e1a' }}>
                Try {ind.name.split(' ')[0]} IVR →
              </Link>
            </div>
          ))}
        </div>
      </div>
    </PageShell>
  )
}
