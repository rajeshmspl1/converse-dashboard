'use client'
import Link from 'next/link'
import PageShell from '@/components/PageShell'

const TIERS = [
  { exp: 5, name: 'Essential', tag: 'Functional', color: '#8a4ee8', stack: 'Azure STT · GPT-4o-mini · Azure TTS', price: '₹0.47', usd: '$0.006', latency: '~900ms', desc: 'Functional IVR replacement. Best for high-volume, simple intents.', popular: false },
  { exp: 4, name: 'Sarvam', tag: 'Smart Indic', color: '#3370e8', stack: 'Sarvam STT · GPT-4o-mini · Sarvam TTS', price: '₹0.50', usd: '$0.006', latency: '~800ms', desc: 'Best for Indian language support. Hindi, Tamil, Telugu + 10 more.', popular: false },
  { exp: 3, name: 'Gemini', tag: 'Best Value', color: '#18c48a', stack: 'Gemini 2.5 Flash (end-to-end)', price: '₹1.05', usd: '$0.013', latency: '~300ms', desc: 'Best value. Fast, conversational, great voice quality.', popular: true },
  { exp: 2, name: 'Conversational', tag: 'NRI-Ready', color: '#e09820', stack: 'GPT-4o Realtime (end-to-end)', price: '₹1.47', usd: '$0.018', latency: '~300ms', desc: 'NRI-ready. Emotional AI. Best for high-value customers.', popular: false },
  { exp: 1, name: 'Ultra Premium', tag: 'Human-Like', color: '#ef4444', stack: 'ElevenLabs · GPT-4o-mini · Azure STT', price: '₹3.75', usd: '$0.045', latency: '~700ms', desc: 'Human-like voice. Premium brand experience.', popular: false },
]

const INCLUDED = [
  { icon: '🔌', title: 'Zero Integration', desc: 'No SIP, no API, no code changes. Your IVR stays live and unchanged.' },
  { icon: '🎙️', title: 'Full call recording', desc: 'Recordings, transcripts, intent analytics, and CSAT proxy — all included.' },
  { icon: '🌐', title: 'Multilingual', desc: '10+ Indian languages auto-detected per call. No configuration needed.' },
  { icon: '🤝', title: 'Agent handoff', desc: 'Seamless transfer with full context. Zero dead air. Configurable thresholds.' },
  { icon: '📊', title: 'Real-time dashboard', desc: 'Live call monitoring, intent analytics, cost tracking, containment rates.' },
  { icon: '🛡️', title: 'Data sovereignty', desc: 'Shared, dedicated, or on-premise. India, UAE, EU regions available.' },
]

const LAYERS = [
  { title: 'Layer 1 · IVR Intent Resolution', desc: 'Pay per resolved intent. Unresolved → credited back.', price: '₹0.47–₹3.75', active: true },
  { title: 'Layer 2 · Sales Intent Detection', desc: 'Flat fee per sales lead detected during IVR calls.', price: 'Flat fee', active: false, tag: 'Coming Soon' },
  { title: 'Layer 3 · Sales Commission', desc: 'Commission per confirmed sales conversion.', price: 'Commission', active: false, tag: 'Coming Soon' },
]

const FAQ = [
  { q: 'What counts as a resolved intent?', a: 'A customer asks for something (balance check, card block, etc.) and the AI successfully completes it. If the AI can\'t resolve and transfers to a human agent, you\'re credited back.' },
  { q: 'What if the customer disconnects early?', a: 'Zero cost. You only pay for resolved intents. Hang-ups, idle time, hold time — all free.' },
  { q: 'Can I mix experience tiers?', a: 'Yes. With Customer Value Routing, your Gold customers get Exp 2 while Bronze gets Exp 5 — automatically, per call, based on CRM tier.' },
  { q: 'Is there a minimum commitment?', a: 'No. Free UAT for 3 months. No credit card required. Cancel anytime.' },
  { q: 'How does this compare to traditional IVR?', a: 'Traditional IVR ports bill ₹6–8/min regardless of outcome. Agent calls cost ₹3–5/min. Converse AI starts at ₹0.47/intent — typically 90%+ savings.' },
]

export default function PricingPage() {
  return (
    <PageShell>
      {/* Hero */}
      <div className="max-w-[940px] mx-auto px-6 pt-12 pb-8 text-center">
        <div className="text-[11px] font-semibold uppercase tracking-[2px] mb-2" style={{ color: 'var(--dim)' }}>
          Transparent · No surprises
        </div>
        <h1 className="text-[32px] font-bold mb-3" style={{ color: 'var(--bright)' }}>Per-Intent Pricing</h1>
        <p className="text-[14px] max-w-[560px] mx-auto leading-relaxed" style={{ color: 'var(--text)' }}>
          You pay when AI resolves a customer intent. Disconnects, hold time, idle calls — all cost zero.
        </p>
      </div>

      {/* Tier cards */}
      <div className="max-w-[940px] mx-auto px-6 pb-14">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {TIERS.map(t => (
            <div key={t.exp} className="rounded-xl p-5 text-center relative"
              style={{
                background: 'var(--card)',
                border: t.popular ? '2px solid var(--green)' : '1px solid var(--b1)',
              }}>
              {t.popular && (
                <div className="absolute -top-2.5 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded text-[8px] font-bold"
                  style={{ background: 'var(--green)', color: '#050e1a' }}>MOST POPULAR</div>
              )}
              <div className="text-[9px] font-bold uppercase tracking-[1px] mb-2" style={{ color: t.color }}>
                Exp {t.exp} · {t.name}
              </div>
              <div className="text-[10px] mb-1" style={{ color: 'var(--dim)' }}>{t.stack}</div>
              <div className="font-mono text-[28px] font-bold my-2"
                style={{ color: t.popular ? 'var(--green)' : 'var(--bright)' }}>{t.price}</div>
              <div className="text-[10px]" style={{ color: 'var(--dim)' }}>
                per intent · {t.usd} · {t.latency}
              </div>
              <div className="text-[9px] mt-3 pt-3 leading-relaxed"
                style={{ color: 'var(--dim)', borderTop: '1px solid var(--b1)' }}>{t.desc}</div>
              <Link href="/"
                className="inline-block mt-3 px-5 py-2 rounded-lg text-[10px] font-bold no-underline transition-opacity hover:opacity-85"
                style={{
                  background: t.popular ? 'var(--green)' : 'rgba(24,196,138,.1)',
                  color: t.popular ? '#050e1a' : 'var(--green)',
                }}>
                Try Free →
              </Link>
            </div>
          ))}
        </div>
      </div>

      {/* What's included */}
      <div className="border-t" style={{ borderColor: 'var(--b1)' }}>
        <div className="max-w-[940px] mx-auto px-6 py-14">
          <h2 className="text-[22px] font-bold text-center mb-8" style={{ color: 'var(--bright)' }}>
            What's included in every plan
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {INCLUDED.map(item => (
              <div key={item.title} className="rounded-xl p-5 border" style={{ background: 'var(--card)', borderColor: 'var(--b1)' }}>
                <div className="text-[18px] mb-2">{item.icon}</div>
                <div className="text-[13px] font-bold mb-1" style={{ color: 'var(--bright)' }}>{item.title}</div>
                <div className="text-[11px] leading-relaxed" style={{ color: 'var(--dim)' }}>{item.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* How billing works */}
      <div className="border-t" style={{ borderColor: 'var(--b1)' }}>
        <div className="max-w-[600px] mx-auto px-6 py-14">
          <h2 className="text-[22px] font-bold text-center mb-2" style={{ color: 'var(--bright)' }}>
            How billing works
          </h2>
          <p className="text-center text-[13px] mb-8" style={{ color: 'var(--dim)' }}>
            Three layers of billing — you only pay what applies.
          </p>
          <div className="flex flex-col gap-2">
            {LAYERS.map(l => (
              <div key={l.title} className="rounded-xl p-4 border flex items-center justify-between"
                style={{
                  background: 'var(--card)',
                  borderColor: 'var(--b1)',
                  opacity: l.active ? 1 : 0.5,
                }}>
                <div>
                  <div className="text-[13px] font-bold flex items-center gap-2" style={{ color: 'var(--bright)' }}>
                    {l.title}
                    {l.tag && (
                      <span className="text-[8px] px-2 py-0.5 rounded" style={{ background: 'var(--card2)', color: 'var(--dim)' }}>
                        {l.tag}
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] mt-1" style={{ color: 'var(--dim)' }}>{l.desc}</div>
                </div>
                <div className="text-[12px] font-bold flex-shrink-0 ml-4"
                  style={{ color: l.active ? 'var(--green)' : 'var(--dim)' }}>{l.price}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* FAQ */}
      <div className="border-t" style={{ borderColor: 'var(--b1)' }}>
        <div className="max-w-[600px] mx-auto px-6 py-14">
          <h2 className="text-[22px] font-bold text-center mb-8" style={{ color: 'var(--bright)' }}>
            Pricing FAQ
          </h2>
          {FAQ.map(f => (
            <div key={f.q} className="py-4 border-b" style={{ borderColor: 'var(--b1)' }}>
              <div className="text-[13px] font-bold mb-1" style={{ color: 'var(--bright)' }}>{f.q}</div>
              <div className="text-[11px] leading-relaxed" style={{ color: 'var(--dim)' }}>{f.a}</div>
            </div>
          ))}
        </div>
      </div>
    </PageShell>
  )
}
